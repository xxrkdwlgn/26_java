package day02;

public class HELLO0310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.print("알고리즘 프로그램 만들기");
	}

}
