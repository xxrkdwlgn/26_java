package day02;

public class DataTypeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 1. 기본형
		boolean isTrue;
		int age;
		double height, weight;
		
		// 2. 변수 초기화
		isTrue = false;
		age = 20;
		height = 189.5;
		weight =90.12;
		
		
		
		// 2.레퍼런스형 -3개 (배열,클래스,인터페이스)
		String name = "강지후";
		String address = "용인";
		// name  = "강지후";
		String  s = new String("강지후");
		
		DataTypeTest dtt = new DataTypeTest();
		//주소 addr
		 
		
		
		//3. 변수 값 출력하기
		System.out.println(isTrue);
		System.out.println("나이:"+age);
		System.out.println("키:"+height);
		System.out.println("몸무게:"+weight);		
		System.out.println("주소:"+address);		
		            
		
	}
	
}
