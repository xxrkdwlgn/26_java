package day02;

public class HELLO {

	public static void main(String[] args) {
	// TODO Auto-generated method stub
	
		
		System.out.print("반갑습니다 열심히 자바공부해요\n줄바꿨습니다");
		System.out.print("반갑습니다 열심히 자바공부해요\n줄바꿨습니다");
		
		
	}
	
}
