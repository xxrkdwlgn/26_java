package day07;

public class admin extends personny {
    private String id = "admin";
    private String passwd = "1234";

    // 생성자
    public admin(String name, int phone) {
        super(name, phone);
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public String getId() {
        return id;
    }

    public String getPasswd() {
        return passwd;
    }
}