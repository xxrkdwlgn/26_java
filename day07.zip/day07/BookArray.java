package day07;
import java.util.Scanner;



public class BookArray {
	public static void main(String[] args) {
		book[] book = new book[2];
		
		Scanner scanner = new Scanner(System.in);
		for(int i = 0; i<book.length; i++) {
			System.out.println("제목>>");
			String title = scanner.nextLine();
			System.out.println("저자>>");
			String auther = scanner.nextLine();
			book[i] = new book(title, auther);
		}
		for(int i = 0; i < book.length; i++) {
			System.out.println("(" + book[i].title + ", " + book[i].auther + ")");
			scanner.close();
		}
	}

}
