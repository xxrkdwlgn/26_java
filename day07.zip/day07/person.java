package day07;

public class person {
    // 필드(변수)
    public static String name;
    public int age;
    public char abc;

    // 기본 생성자
    public person() {
        name = "홍길동";
        age = 20;
        abc = 'A';
        System.out.println("객체가 생성됨.");
    }

    public static String getName() {
        return name;
    }

    // 메소드
    public void 밥먹기() {
        System.out.println("밥먹다.");
    }

    public void 운동하기(String s) {
        System.out.println(s + "종목을 운동합니다.");
    }
}