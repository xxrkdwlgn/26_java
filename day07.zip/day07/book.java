package day07;

public class book {
	String title;
	String auther;
	
	public book(String t)  {
		//생성자
		title = t; auther = "작자미상";
	}
	public book(String t, String a) {
		//생성자
		title = t; auther = a;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		book litlleprince = new book("어린 왕자", "생텍쥐페리");
		book lovestory = new book("춘향전");
		System.out.println(litlleprince.title + "" + litlleprince.auther);
		System.out.println(lovestory.title + "" + lovestory.auther);
	}

}
