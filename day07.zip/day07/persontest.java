package day07;

public class persontest {

    public static void main(String[] args) {
        // Person 객체 생성하기
        person hong = new person(); // 디폴트 생성자 함수
//      hong.name = "홍길동";
//      hong.age = 20;
//      hong.abc = 'A';
        hong.밥먹기();
        hong.운동하기("헬스");

        person kang = new person();
//      kang.name = "고승연";
//      kang.age = 21;
//      kang.abc = 'B';
        kang.밥먹기();
        kang.운동하기("숨쉬기");

        //hong.addr = "대전 동구 용운동"

        System.out.println(hong.getName());
    }
}