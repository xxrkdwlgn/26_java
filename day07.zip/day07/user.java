package day07;

public class user extends personny {
	
	String addr;
	
	public user(String name, int phone, String addr) {
		super(name,phone);
		this.addr = addr;
	}

}
