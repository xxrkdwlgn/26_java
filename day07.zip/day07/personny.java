package day07;

public class personny {
	
	String name;
	int phone;
	
	public personny(String name, int phone) {
		this.name =name;
		this.phone = phone;
	}

}
