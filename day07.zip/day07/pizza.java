package day07;

class Circle {
    int radius;   // 원의 반지름 필드
    String name;  // 원의 이름 필드

    public Circle() {
        this(0, "");
    }

    public Circle(int radius) {
        this(radius, "불고기피자");
    }

    public Circle(int radius, String name) {
        this.radius = radius;
        this.name = name;
    }

    public double getArea() {
        return 3.14 * radius * radius;
    }
}

public class pizza {
    public static void main(String[] args) {
        Circle pizza = new Circle(10);
        Circle pizza2 = new Circle(10, "치즈피자");
        //pizza.radius = 10;
        //pizza.name = "불고기피자";
        //System.out.println(pizza.name + "의 면적은 " + pizza.getArea());
        System.out.println(pizza2.name + "의 면적은 " + pizza2.getArea());

        Circle donut = new Circle();
        donut.radius = 2;
        donut.name = "자바도넛";
        double area = donut.getArea();
        System.out.println(donut.name + "의 면적은 " + area);
    }
}