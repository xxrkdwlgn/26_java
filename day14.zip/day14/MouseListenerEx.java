package day14;

import java.awt.Container;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.*;

public class MouseListenerEx extends JFrame {

    JLabel lb;

    public MouseListenerEx() {
        Container con = getContentPane();

        con.setLayout(null);

        lb = new JLabel("hello");
        lb.setSize(50, 20);
        lb.setLocation(30, 30);
        con.add(lb);

        con.addMouseListener(new MyMouseListener());

        setSize(400, 400);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new MouseListenerEx();
    }

    class MyMouseListener extends MouseAdapter {

        @Override
        public void mousePressed(MouseEvent e) {
            int x = e.getX();
            int y = e.getY();

            lb.setLocation(x, y);
        }
    }
}