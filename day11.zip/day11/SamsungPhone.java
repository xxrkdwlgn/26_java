package day11;

public class SamsungPhone implements PhoneInterface {

	public static void main(String[] args) {
		SamsungPhone sp = new SamsungPhone();
		sp.sendCall();
		sp.receiveCall(); 
		
		PhoneInterface pi = new SamsungPhone();
	}

	

public void sendCall() {
	System.out.println("띠리리리링");
}


public void receiveCall() {
	System.out.println("전화받아요");
	
}

}
