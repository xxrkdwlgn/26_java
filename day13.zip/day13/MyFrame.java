package day13;

import javax.swing.JFrame;

public class MyFrame {

    public static void main(String[] args) {

        JFrame jf = new JFrame();

        jf.setSize(300, 300);
        jf.setTitle("300x300 사이즈의 프레임");
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setVisible(true);
    }
}