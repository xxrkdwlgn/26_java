package day13;

import javax.swing.*;
import java.awt.*;

public class Layout extends JFrame {

    public Layout() {
        setTitle("계산 화면");
        setSize(300, 250);

        JPanel titlePanel = new JPanel();
        titlePanel.setBounds(0, 0, 300, 40);
        add(titlePanel);

        JLabel title = new JLabel("계산기", JLabel.CENTER);
        title.setFont(new Font("함초롬돋움", Font.BOLD, 20));
        titlePanel.add(title);

        JPanel numPanel = new JPanel();
        numPanel.setBounds(0, 40, 300, 40);
        numPanel.setLayout(new FlowLayout(FlowLayout.CENTER));

        JTextField num01 = new JTextField(5);
        JTextField num02 = new JTextField(5);

        numPanel.add(num01);
        numPanel.add(num02);
        add(numPanel);

        JPanel opPanel = new JPanel();
        opPanel.setBounds(90, 80, 120, 70);
        opPanel.setLayout(new GridLayout(2, 2, 10, 10));

        JButton btn01 = new JButton("+");
        JButton btn02 = new JButton("-");
        JButton btn03 = new JButton("*");
        JButton btn04 = new JButton("/");

        opPanel.add(btn01);
        opPanel.add(btn02);
        opPanel.add(btn03);
        opPanel.add(btn04);
        add(opPanel);

        JPanel resultPanel = new JPanel();
        resultPanel.setBounds(0, 160, 300, 40);
        add(resultPanel);

        JLabel label01 = new JLabel("계산결과 : ");
        JLabel label02 = new JLabel("");

        resultPanel.add(label01);
        resultPanel.add(label02);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Layout();
    }
}