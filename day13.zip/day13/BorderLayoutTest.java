package day13;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class MyActionListener implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {

        JButton jbtn = (JButton) e.getSource();

        if (jbtn.getActionCommand().equals("add")) {
            System.out.println("더하기 버튼이 클릭 됨");
        } 
        else if (jbtn.getActionCommand().equals("sub")) {
            System.out.println("빼기 버튼이 클릭 됨");
        } 
        else if (jbtn.getActionCommand().equals("mul")) {
            System.out.println("곱하기 버튼이 클릭 됨");
        } 
        else if (jbtn.getActionCommand().equals("div")) {
            System.out.println("나누기 버튼이 클릭 됨");
        } 
        else if (jbtn.getActionCommand().equals("center")) {
            System.out.println("계산기 버튼이 클릭 됨");
        }
    }
}

public class BorderLayoutTest extends JFrame {

    JButton btn1, btn2, btn3, btn4, btn5;

    public BorderLayoutTest() {
        setSize(250, 250);
        setTitle("세번째 프레임");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new BorderLayout());

        btn1 = new JButton("add");
        btn2 = new JButton("sub");
        btn3 = new JButton("mul");
        btn4 = new JButton("div");
        btn5 = new JButton("center");

        // 이벤트 리스너 객체 생성
        MyActionListener listener = new MyActionListener();

        // 버튼에 이벤트 연결
        btn1.addActionListener(listener);
        btn2.addActionListener(listener);
        btn3.addActionListener(listener);
        btn4.addActionListener(listener);
        btn5.addActionListener(listener);

        add(btn1, BorderLayout.NORTH);
        add(btn2, BorderLayout.SOUTH);
        add(btn3, BorderLayout.WEST);
        add(btn4, BorderLayout.EAST);
        add(btn5, BorderLayout.CENTER);

        setVisible(true);
    }

    public static void main(String[] args) {
        new BorderLayoutTest();
    }
}