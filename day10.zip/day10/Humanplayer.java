package day10;

import java.util.Scanner;

public class Humanplayer extends Player {
    private Scanner scanner = new Scanner(System.in);

    public Humanplayer(String name) {
        super(name);
    }

    @Override
    public String turn() {
        System.out.print(getName() + "님, 뭘 내시겠습니까? ");
        return scanner.next();
    }
}