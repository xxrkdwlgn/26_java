package day10;

class CCTV {
    private String resolution;

    // 생성자
    public CCTV(String resolution) {
        this.resolution = resolution;
    }

    // getter
    public String getResolution() {
        return resolution;
    }
}

public class AICCTV extends CCTV {
    boolean facecheck;

    public AICCTV(String resolution, boolean check) {
        super(resolution);
        this.facecheck = check;
    }

    public void printinfo() {
        if (getResolution().equals("FHD") && facecheck == true) {
            System.out.println("CCTV는 FHD급 해상도이고, 현재 얼굴인식 작동 중");
        } else if (getResolution().equals("FHD") && facecheck == false) {
            System.out.println("CCTV는 FHD급 해상도이고, 얼굴인식은 작동하지 않음");
        } else {
            System.out.println("해상도가 낮습니다.");
        }
    }

    public static void main(String[] args) {
        AICCTV ai = new AICCTV("FHD", true);
        ai.printinfo();
    }
}