package day10;

public class Circle extends Shape {
	//메소드 오버라이딩
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("원을 그리다");
	}

}