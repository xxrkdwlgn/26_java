package day09;

public class animaltest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		animal cat = new animal();
		Human hong = new Human();
		
		
		// honf.name = "홍길동"
		hong.setName("홍길동");
		//cat.name = "뽀삐";
		cat.setName("뽀삐");
		//cat.age = 10;
		cat.setAge(10);
		hong.setAge(25);
		
		System.out.println(cat.getAge());
		System.out.println(hong.getName());
		System.out.println(hong.getAddr());
		
	}

}
