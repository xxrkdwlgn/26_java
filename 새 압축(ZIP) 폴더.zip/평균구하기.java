package day05;

public class 평균구하기 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
