package day06;
import java.util.Scanner;
public class Method3 {

   // 2개의 정수를 입력 받아서 최대값을 반환하는 max() 메소드를 정의하고 호출 한 후 결과를 출력하시오.
   public static int add(int a, int b, String s) {   
   return a+b;
   }
   public static int sub(int a, int b, String s) {   
   return a-b;
   }
   public static int mul(int a, int b, String s) {   
   return a*b;
   }
   public static int div(int a, int b, String s) {   
   return a/b;
   }
   
   
   public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      
      int a,b,max;
      
      System.out.println("정수 1 입력: ");
      a = sc.nextInt();
      System.out.println("정수 2 입력:");
      b = sc.nextInt();
      System.out.println("연산 부호를 입력: ");
      String s = sc.next();
      
     switch(s) {
     case "+":
    	 System.out.println(a + "+" +b + "=" + add(a,b,s));
    	 break;
     case "-":
    	 System.out.println(a + "-" +b + "=" + sub(a,b,s));
    	 break;
     case "*":
    	 System.out.println(a + "*" +b + "=" + mul(a,b,s));
    	 break;
     case "/":
    	 System.out.println(a + "/" +b + "=" + div(a,b,s));
    	 break;
     }
      
   }
   
}
