package day06;
import java.util.Scanner;
public class Add {

	public static void main(String[] args) {
		// 2개의 실수를 입력 받아서 더한 결과를 출력하시오.
		 double num1, num2, num3;
		 
		 Scanner scanner = new Scanner(System.in);
		System.out.println("첫번째 실수를 입력하시요. ");
		num1 = scanner.nextDouble();
		System.out.println("두번쨰 실수를 입력하세요: ");
		num2 = scanner.nextDouble();
		num3 = num1*num2;
		
		System.out.println("결과는" +num3 + "입니다");
		
		 
		
		
		
	}

}
