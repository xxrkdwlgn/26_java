package day06;
import java.util.Scanner;
public class Method2 {

   // 2개의 정수를 입력 받아서 최대값을 반환하는 max() 메소드를 정의하고 호출 한 후 결과를 출력하시오.
   public static int max(int a, int b) {   
   int maxNum = a;
         if(b> maxNum) {
            maxNum = b;
         }
         return maxNum;
   }
   
   public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      
      int a,b,max;
      
      System.out.println("정수 1 입력: ");
      a = sc.nextInt();
      System.out.println("정수 2 입력:");
      b = sc.nextInt();
      
      max = max(a,b);
      
      System.out.println("최대값: " + max);
      
   }
   
}
